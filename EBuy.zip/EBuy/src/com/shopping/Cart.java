package com.shopping;
import com.Model.item;
import java.util.ArrayList;

public class Cart {
    private final static Cart cart=new Cart();
    private final ArrayList<item> items = new ArrayList<>();;
    private  int totalAmount;
    private int count;
    private int productId;
   private static Cart getInstance()
   {
       return cart;
   }

public void removeAll()
{
    items.clear();
}

public void increaseQuantity(int count ,int productId)
{
    for (item item:items)
    {
        if(item.getProductId()==productId)
        {
            item.setQuantity(count);
        }
    }

}
public void reduceQuantity(int count,int productId)
{
    for (item item:items)
    {
        if(item.getQuantity()==productId)
        {
            item.reduceQuantity(count);
        }
    }
}


}

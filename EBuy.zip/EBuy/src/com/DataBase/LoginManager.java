package com.DataBase;


import com.Model.Address;
import com.Model.Admin;
import com.Model.Customer;
import com.Model.User;
import java.util.ArrayList;



public class LoginManager {
    private static final LoginManager loginManager=new LoginManager();
    private LoginManager()
    {


    }

    private final ArrayList<User> Login=new ArrayList<User>()
    {
        {
            add(new Admin("arunji12345.ak@gmail.com","Arun@1234", User.UserTypes.Admin));
            add(new Admin("joo123@zohocorp.com","Joo@123", User.UserTypes.Admin));
            add(new Customer("mb.arun1407@gmail.com","Arun@123", User.UserTypes.Customer,"ArunKumar",new Address(2,"Main Road","Villupuram","Pondicherry","Pondicherry",605102),"9487545391"));
        }
    };
    public ArrayList<User> getLogin()
    {
        return Login;
    }
   public void SetLogin(Customer customer)
    {
        Login.add(customer);
    }
public static LoginManager getInstance()
{
    return loginManager;
}
}

package com.DataBase;


import com.Model.Product;

import java.util.ArrayList;

public class ProductDB {
     ProductDB productDB=new ProductDB();
 public static final  ArrayList<Product> productData=new ArrayList<Product>();

    static {
        //mobiles
        productData.add(new Product(1000, "      Mobile    ", "Mi        ", 5000, 2342));
        productData.add(new Product(1001, "      Mobile    ", "OnePlus   ", 5000, 2344));
        productData.add(new Product(1002, "      Mobile    ", "Redmi     ", 5000, 2346));
        productData.add(new Product(1003, "      Mobile    ", "Oppo      ", 5000, 2345));
        productData.add(new Product(1004, "      Mobile    ", "Apple     ", 5000, 23427));
        productData.add(new Product(1005, "      Mobile    ", "Honour    ", 5000, 23424));
        productData.add(new Product(1006, "      Mobile    ", "Samsung   ", 5000, 234233));
        productData.add(new Product(1007, "      Mobile    ", "Nokia     ", 5000, 234289));
        // Laptops
        productData.add(new Product(2000, "      Laptop    ", "Acer      ", 25000, 2342435));
        productData.add(new Product(2001, "      Laptop    ", "HP        ", 35000, 23342));
        productData.add(new Product(2002, "      Laptop    ", "ChromeBook", 55000, 42342));
        productData.add(new Product(2003, "      Laptop    ", "Dell      ", 45000, 242342));
        // HeadPhones
        productData.add(new Product(2005, "      HeadPhones", "Mi        ", 600, 112342));
        productData.add(new Product(2006, "      HeadPhones", "Boat      ", 2000, 2342342));
        productData.add(new Product(2007, "      HeadPhones", "RealMe    ", 700, 112342));
        productData.add(new Product(2009, "      HeadPhones", "Sony      ", 500, 234342));

        //Camera
        productData.add(new Product(2100, "      Camera    ", "Canon     ", 60000, 112));
        productData.add(new Product(2101, "      Camera    ", "Sony      ", 20000, 2342));
        productData.add(new Product(2102, "      Camera    ", "Nikon     ", 70000, 1123));
        productData.add(new Product(2103, "      Camera    ", "GoPro     ", 50000, 234));


    }

    public ProductDB getProductDB() {
        return productDB;
    }

    public void setProductDB(ProductDB productDB) {
        this.productDB = productDB;
    }

    public static ArrayList<Product> getProductData() {
        return productData;
    }

}

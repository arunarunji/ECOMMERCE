package com.DataBase;



import java.util.ArrayList;
import java.util.HashMap;

public class CategoryDb {
    HashMap<String , ArrayList<Integer>> Electronics=new HashMap<String,ArrayList<Integer>>()
    {
        {
            Electronics.put("Laptop",laptopList);
            Electronics.put("Mobile",mobileList);
            Electronics.put("Camera",cameraList);
            Electronics.put("HeadPhones",headPhonesList);
        }
    };
    ArrayList<Integer> laptopList=new ArrayList<Integer>() {
        {
            laptopList.add(2000);
            laptopList.add(2001);
            laptopList.add(2002);
            laptopList.add(2003);

    }
    };
ArrayList<Integer> mobileList=new ArrayList<Integer>()
{
    {
        mobileList.add(1000);
        mobileList.add(1001);
        mobileList.add(1002);
        mobileList.add(1003);
        mobileList.add(1004);
        mobileList.add(1005);
        mobileList.add(1006);
        mobileList.add(1007);
    }
};
ArrayList<Integer> headPhonesList =new ArrayList<Integer>()

{
    {
        headPhonesList.add(2005);
        headPhonesList.add(2006);
        headPhonesList.add(2007);
        headPhonesList.add(2009);
    }
};
ArrayList<Integer> cameraList=new ArrayList<Integer>()
{
    {
        cameraList.add(2100);
        cameraList.add(2101);
        cameraList.add(2102);
        cameraList.add(2103);
    }
};
}

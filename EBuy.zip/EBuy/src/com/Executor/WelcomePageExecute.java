package com.Executor;

import com.Navigator.Navigator;
import com.Navigator.SignInPageNavigator;
import com.Navigator.WelcomePageChoice;
import com.Navigator.WelcomePageNavigator;

public class WelcomePageExecute implements Execute {
    private static boolean run = true;
    private final WelcomePageChoice choice;

    public WelcomePageExecute(WelcomePageChoice choice) {
        this.choice = choice;   }

    public static boolean isRun() {

        return run;
    }

    public static void setRun(boolean run) {

       WelcomePageExecute.run = run;
    }

    @Override
    public void execute() {
        switch (choice) {

            case A:
            {
                final Navigator navigator = new SignInPageNavigator();
                navigator.navigate();
                break;
            }
            case B: {
                WelcomePageNavigator.setStartRun(false);
                System.out.println("Thank you for using the application , Have a Nice day :)!!");
                break;
            }
            default:
                System.out.println("Pls Enter the Valid Option :)");


        }
    }
}

package com.Executor;



public class SubCategoryChoiceB implements Execute {
    @Override
    public void execute() {

    }
}

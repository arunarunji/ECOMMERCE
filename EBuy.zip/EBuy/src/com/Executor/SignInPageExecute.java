package com.Executor;

import com.DataBase.LoginManager;
import com.Model.Address;
import com.Model.Customer;
import com.Model.User;
import com.Navigator.CategoryMenu;
import com.Navigator.Navigator;
import com.Navigator.SignInPageChoice;
import com.Validator.InputDataValidator;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class SignInPageExecute implements Execute {
    private final Scanner in=new Scanner(System.in);
    private final SignInPageChoice choice;
    private  String email;
    LoginManager loginManager=LoginManager.getInstance();
    ArrayList<User> userData=loginManager.getLogin();


    public SignInPageExecute(SignInPageChoice choice)
    {
        this.choice=choice;
    }



    @Override
    public void execute() {
        switch (choice) {
            case A:
                SignUp();
                break;
            case B:
                if (!checkLogin())
                    System.out.println("Pls Enter correct Email and Password OR Pls Create New Account ");

                else {
                    System.out.println("LOGGED IN SUCCESSFULLY ....");
                    WelcomePageExecute.setRun(false);
                    final Navigator n = new CategoryMenu();
                    n.navigate();

                }
                break;
            default:
                System.out.println("Pls Enter the Valid choice....");
                break;
        }
    }
    public boolean checkLogin() {
        String email="";
        String password="";
        while(InputDataValidator.validateEmail(email)) {
            System.out.println("Enter the UserEmailId");
            email = in.nextLine().trim();
            if (InputDataValidator.validateEmail(email))
                System.out.println("Invalid Email,Pls Enter the Valid Email ");
        }
        while (InputDataValidator.validatePassword(password)) {
            System.out.println("Enter the Password  ");
            password = in.nextLine().trim();
            if (InputDataValidator.validatePassword(password))
                System.out.println("Invalid Password,Pls Enter the Valid Password ");
        }
return CheckUserExist(userData,email,password);

    }
    public void SignUp() {
        String email="";
        String password="";
        String name="";
        String phNumber="";
        while(InputDataValidator.validateEmail(email)) {
            System.out.println("Enter the UserEmailId");
            email = in.nextLine().trim();
            if(CheckEmailExist(userData,email)) {
                if (InputDataValidator.validateEmail(email))
                    System.out.println("Invalid Email,Pls Enter the Valid Email ");
            }
            else
            {
                System.out.println("Customer EmailId Already Exists ");
            }
        }
          while (InputDataValidator.validatePassword(password)) {
              System.out.println("Enter the Password  ");
              password = in.nextLine().trim();
              if (InputDataValidator.validatePassword(password))
                  System.out.println("Invalid Password,Pls Enter the Valid Password ");
          }
        while (InputDataValidator.validateName(name)) {
            System.out.println("Enter the CustomerName");
            name=in.nextLine().trim();
            if (InputDataValidator.validateName(name))
                System.out.println("Invalid Customer Name,Pls Enter the Valid Customer Name ");
        }
        while (InputDataValidator.validatePhone(phNumber)) {
            System.out.println("Enter the Phone Number ");
            phNumber=in.nextLine().trim();
            if (InputDataValidator.validatePhone(phNumber))
                System.out.println("Invalid Phone Number ,Pls Enter the Valid phone Number ");
        }
            Address address=new Address(2,"Main Road","Villupuram","Pondicherry","Pondicherry",605102);
            Customer customer=new Customer(email,password, User.UserTypes.Customer,name,address,phNumber);
            loginManager.SetLogin(customer);
          System.out.println("Login is SuccessFully Created ..");
        }
      public boolean CheckEmailExist(ArrayList<User> User,String email)
      { boolean flag=false;
          for(User user:User)
              if (Objects.equals(user.getUserMailId(), email)) {
                  flag = true;
                  break;
              }
          return flag;
      }
        public boolean CheckUserExist(ArrayList<User>User,String email,String password)
        {
            boolean flag=false;
            for (User user:User)
            {
                if (Objects.equals(user.getUserMailId(), email)&&Objects.equals(user.getUserPassword(),password)) {
                    flag=true;

                }
            }
            return flag;
        }
    }



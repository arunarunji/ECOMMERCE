package com.Executor;

public interface Execute {

    void execute();
        }

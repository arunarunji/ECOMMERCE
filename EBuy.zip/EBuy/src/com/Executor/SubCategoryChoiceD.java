package com.Executor;



public class SubCategoryChoiceD implements Execute {

    @Override
    public void execute() {

    }
}

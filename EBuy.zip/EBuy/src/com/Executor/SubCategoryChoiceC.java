package com.Executor;



public class SubCategoryChoiceC implements Execute {
    @Override
    public void execute() {

    }
}

package com.Executor;

import com.Navigator.*;

public class CategoryMenuExecute implements Execute {
    private final CategoryChoice  choice;
    public CategoryMenuExecute(CategoryChoice  choice)
    {
        this.choice=choice;
    }

    @Override
    public void execute() {
        switch (choice) {
            case A:
                Execute a=new SubCategoryChoiceA();
                a.execute();
                break;
            case B:
                Execute b=new SubCategoryChoiceB();
                b.execute();
                break;
            case C:
                Execute c=new SubCategoryChoiceC();
                c.execute();
            case D:
                Execute d= new SubCategoryChoiceD();
                d.execute();
            case E:
                Execute e=new SubCategoryChoiceE();
                e.execute();
            default:
                System.out.println("Pls Enter the Valid choice....");
                break;
        }
    }
}

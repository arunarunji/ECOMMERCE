package com.Executor;

import com.Executor.Execute;

public class SubCategoryChoiceA implements Execute {
    @Override
    public void execute() {

    }
}

package com.Model;

public class Prod {
    String productName;
    int productId;
    double price;

    public Prod(String productName, int  productId, double price)
    {
        this.price=price;
        this.productName=productName;
        this.productId=productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}

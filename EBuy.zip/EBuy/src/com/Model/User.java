package com.Model;

public abstract class User {
    public enum UserTypes{
         Admin ,Customer
        }

       private final String userMailId;
        private String  userPassword;
        public final  UserTypes userType;
        public User(String userMailId,String userPassword, UserTypes userType) {
           this.userMailId = userMailId;
            this.userPassword = userPassword;
            this.userType = userType;
        }

    public String getUserMailId() {
        return userMailId;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public UserTypes getUserType() {
        return userType;
    }
}


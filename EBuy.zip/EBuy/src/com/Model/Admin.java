package com.Model;



public class Admin extends User {
private final int accessCode=1212;
    public enum AdminMenu {
        viewAllProduct, addProduct, removeProduct, viewCustomerDetail, viewAdminDetail
    }
    public Admin(String userMailId, String userPassword,  UserTypes userType) {
        super(userMailId, userPassword, userType);
    }



}

package com.Model;

public class item {
    private final int productId;
    private  int quantity;

    public item(int productId, int quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }

    public int getProductId() {
        return productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity +=quantity;
    }
    public void reduceQuantity(int quantity)
    {
        this.quantity-=quantity;
    }
}

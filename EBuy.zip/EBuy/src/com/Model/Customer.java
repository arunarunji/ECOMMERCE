package com.Model;

public class Customer extends User {
    private String  customerName;
    private Address customerAddress;
    private String customerPhNumber;

    public Customer(String userMailId, String userPassword, User.UserTypes userType, String customerName, Address customerAddress,String customerPhNumber) {
        super(userMailId, userPassword, userType);
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPhNumber = customerPhNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Address getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(Address customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerPhNumber() {
        return customerPhNumber;
    }

    public void setCustomerPhNumber(String customerPhNumber) {
        this.customerPhNumber = customerPhNumber;
    }
}

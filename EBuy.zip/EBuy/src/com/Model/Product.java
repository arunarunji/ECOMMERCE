package com.Model;

import com.DataBase.ProductDB;

public  class Product {

    private final int productId;
    private final String  productName;
    private final String brandName;
    private  int price;
    private int modelNumber;

    public Product(int productId, String productName, String brandName, int price, int modelNumber) {
        this.productId = productId;
        this.productName = productName;
        this.brandName = brandName;
        this.price = price;
        this.modelNumber = modelNumber;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getBrandName() {
        return brandName;
    }

    public int getPrice() {
        return price;
    }

    public int getModelNumber() {
        return modelNumber;
    }


}

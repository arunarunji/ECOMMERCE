package com.Navigator;

import com.Executor.Execute;
import com.Executor.SignInPageExecute;
import com.Executor.WelcomePageExecute;

import java.util.Scanner;

import static com.Executor.WelcomePageExecute.isRun;

public class SignInPageNavigator implements Navigator{

    private static final Scanner in = new Scanner(System.in);
    private static boolean running = true;
    public SignInPageNavigator() {
        WelcomePageExecute.setRun(true);
    }
    public static boolean isRunning() {

        return running;
    }

    public static void setRunning(boolean run) {

        running = run;
    }
    @Override
    public void navigate() {
        while (isRun()) {
            System.out.println("---------- SIGN-IN---------");
            System.out.println();
            for (SignInPageChoice choice : SignInPageChoice.values()) {
                System.out.println("\t\t\t\t\t  " + choice.name() + ". " + choice.getVal());
            }
            System.out.println();
            String choice1 = in.nextLine().trim();
            SignInPageChoice result=validateChoice1(choice1);
            if ( result!= null) {
                final Execute e=new SignInPageExecute(result);
                e.execute();


            } else
                System.out.println("Pls Enter the Valid Choice");


        }
    }
    public SignInPageChoice validateChoice1(String choice1) {


        for (SignInPageChoice h : SignInPageChoice.values()) {
            if (h.toString().equalsIgnoreCase(choice1)) {
                return h;

            }
        }
        return null;
    }
}

package com.Navigator;

public enum SignInPageChoice {
    A("New to EBuy ,Create a new Account"), B("Sign-In");
    private final String val;

    public String getVal() {
        return this.val;
    }

    SignInPageChoice(String val) {
        this.val = val;
    }}

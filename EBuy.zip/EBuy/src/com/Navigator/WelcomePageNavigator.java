package com.Navigator;

import com.Executor.Execute;
import com.Executor.WelcomePageExecute;

import java.util.Scanner;

public class WelcomePageNavigator implements Navigator{
private final Scanner in=new Scanner(System.in);
private static boolean startRun = true;
    public static void setStartRun(boolean start) {

        startRun = start;
    }
    @Override
    public void navigate() {
        while (startRun) {
            System.out.println("\t\t\t\t------ Welcome to AMAZON.in------");
            System.out.println();
            System.out.println("\t\t\t\t--------HomePage------");

            for (WelcomePageChoice choice : WelcomePageChoice.values()) {
                System.out.println("\t\t\t\t\t  " + choice.name() +
                        ". " + choice.getVal());
            }
            System.out.println();
            System.out.println("Pls Enter your Choice ");
            String choice = in.nextLine().trim();
            WelcomePageChoice result=validateChoice(choice);
            if(result!=null)
            {
                final Execute executor =new WelcomePageExecute(result);
                executor.execute();
            }
            else
                System.out.println("Pls Enter the Valid Choice");
        }
    }
    private WelcomePageChoice validateChoice(String choice) {
        for (WelcomePageChoice h : WelcomePageChoice.values()) {
            if (h.toString().equalsIgnoreCase(choice)) {
                return h;

            }
        }
        return null;
    }
}

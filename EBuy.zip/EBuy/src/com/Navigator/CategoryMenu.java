package com.Navigator;

import com.DataBase.ProductDB;
import com.Executor.CategoryMenuExecute;
import com.Executor.Execute;
import com.Model.Product;

import java.util.ArrayList;
import java.util.Scanner;



public class CategoryMenu implements Navigator {

    private static final Scanner in = new Scanner(System.in);
    private static boolean run = true;

    public static boolean isRun() {
        return run;
    }

    public static void setRun(boolean run) {
        CategoryMenu.run = run;
    }

    @Override
    public void navigate() {
        while (isRun()) {

            displayAllProducts(ProductDB.getProductData());
            System.out.println("To View Specific Products  ");
            System.out.println("---------- Categories---------");
            System.out.println();
            for (CategoryChoice choice : CategoryChoice.values()) {
                System.out.println("\t  " + choice.name() + ". " + choice.getVal());
            }
            System.out.println();
            String choice1 = in.nextLine().trim();
            CategoryChoice result = validateChoice1(choice1);
            if (result != null) {
                final Execute e = new CategoryMenuExecute(result);
                e.execute();


            } else
                System.out.println("Pls Enter the Valid Choice");


        }
    }

    public CategoryChoice validateChoice1(String choice1) {


        for (CategoryChoice h : CategoryChoice.values()) {
            if (h.toString().equalsIgnoreCase(choice1)) {
                return h;

            }
        }
        return null;
    }

    private void displayAllProducts(ArrayList<Product> productData) {
        System.out.println("----------------------------------------------------------------------------------------------");
        System.out.println("ProductId       ProductName        BrandName                 Price        ModelNumber ");
        System.out.println("----------------------------------------------------------------------------------------------");

        for (Product product : productData) {
            System.out.println(product.getProductId() + "      " + product.getProductName() + "           " + product.getBrandName() + "              " + product.getPrice() + "         " + product.getModelNumber());
        }

    }
}



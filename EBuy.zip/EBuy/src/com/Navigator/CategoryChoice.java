package com.Navigator;

public enum CategoryChoice {
    A("Electronics"), B("TV&Appliances"),C("Men"),D("WOMENS"),E("BOOKS");
    private final String val;

    public String getVal() {
        return this.val;
    }

    CategoryChoice(String val) {
        this.val = val;
    }}


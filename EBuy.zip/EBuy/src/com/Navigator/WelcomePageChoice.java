package com.Navigator;

public enum WelcomePageChoice {

        A("Go to Login"), B("Quit Application");
        private final String val;

        WelcomePageChoice(String val) {
            this.val = val;
        }

        public String getVal() {
            return this.val;
        }
    }


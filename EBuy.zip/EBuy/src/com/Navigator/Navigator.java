package com.Navigator;

public interface Navigator {
    void navigate();
}

package com.MainClass;

import com.Navigator.Navigator;
import com.Navigator.WelcomePageNavigator;

public class Main {
    public static void main(String[] args) {
        final Navigator navigator=new WelcomePageNavigator();
        navigator.navigate();
    }
}
